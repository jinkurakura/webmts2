
<strong>Copyright &copy; 2016 - <?php echo date('Y'); ?> <a target='_BLANK' href="https://members.phpmu.com"> SIKOLAG Ci 2.0</a>.</strong> All rights reserved. 