<script>
function confirmdelete(delUrl) {
   if (confirm("Anda yakin ingin menghapus?")) {
      document.location = delUrl;
   }
}
</script>


<?php

//cek hak akses user
$cek=user_akses($_GET[module],$_SESSION[sessid]);
if($cek==1 OR $_SESSION[leveluser]=='admin'){

$aksi="modul/mod_linkterkait/aksi_linkterkait.php";
switch($_GET[act]){
//update/////////////////////////////////////

  // Tampil kategori
  default:
echo "<div id=main-content> 
      <div class=container_12> 
      <div class=grid_12> 
      <br/>
	  <a href='?module=linkterkait&act=tambah' class='button'>
     <span>Tambah Link Terkait / Kampus</span>
     </a></div>";

echo "<div class=grid_12> 
      <div class=block-border> 
      <div class=block-header> 
      <h1>LINK TERKAIT</h1>
      <span></span> 
      </div> 
       <div class='block-content'>
		  
     <table id='table-example' class='table'>	  
  	  
    <thead><tr>
      <th>No</th>
      <th>Nama Kampus</th>
      <th>Singkatan</th>
  	  <th>Link / Url</th>
      <th>Aksi</th>
    </thead>
    <tbody>";

    $p      = new Paging;
    $batas  = 15;
    $posisi = $p->cariPosisi($batas);

      $tampil = mysql_query("SELECT * FROM link_terkait ORDER BY id_link DESC");

  
    $no = $posisi+1;
    while($r=mysql_fetch_array($tampil)){
    $lebar=strlen($no);
    switch($lebar){
      case 1:
      {
        $g="0".$no;
        break;     
      }
      case 2:
      {
        $g=$no;
        break;     
      }      
    } 

echo "<tr class=gradeX> 
  <td width=50><center>$g</center></td>
  <td>$r[judul]</td>
  <td>$r[singkatan]</td>
  <td>$r[url]</td>
  <td width=80>
   
  <a href=?module=linkterkait&act=edit&id=$r[id_link] title='Edit' class='with-tip'>
  <center><img src='img/edit.png'></a>
   
  <a href=javascript:confirmdelete('$aksi?module=linkterkait&act=hapus&id=$r[id_link]') title='Hapus' class='with-tip'>
  &nbsp;&nbsp;&nbsp;&nbsp;<img src='img/hapus.png'></center></a> 
   
  </td></tr>";
  
      $no++;
      }
echo "</tbody></table> ";

      $jmldata = mysql_num_rows(mysql_query("SELECT * FROM link_terkait"));

      break;    
	  
//batas update/////////////////////////////////////////////////////////////////////////
  
  // Form Tambah Kategori
  case "tambah":
  
  echo "
   <div id='main-content'>
   <div class='container_12'>

   <div class='grid_12'>
   <div class='block-border'>
   <div class='block-header'>
   
   <h1>TAMBAH LINK TERKAIT</h1>
   </div>
   <div class='block-content'>	
   
   <form method=POST action='$aksi?module=linkterkait&act=input'>
		  
   <p class=inline-small-label> 
   <label for=field4>Nama Kampus</label>
   <input type=text name='judul' size=40>
   </p> 

   <p class=inline-small-label> 
   <label for=field4>Singkatan</label>
   <input type=text name='singkatan' style='width:350px' size=40>
   </p> 

   <p class=inline-small-label> 
   <label for=field4>URL Website</label>
   <input type=text name='url' size=40>
   </p> 
   
      <div class=block-actions> 
      <ul class=actions-right> 
      <li>
      <a class='button red' id=reset-validate-form href='?module=linkterkait'>Batal</a>
      </li> </ul>
      <ul class=actions-left> 
      <li>
      <input type='submit' name='upload' class='button' value=' &nbsp;&nbsp;&nbsp;&nbsp; Simpan &nbsp;&nbsp;&nbsp;&nbsp;'>
	  </li> </ul>
	  </form>";
	  
     break;
  
  // Form Edit Kategori  
  case "edit":
  $edit=mysql_query("SELECT * FROM link_terkait WHERE id_link='$_GET[id]'");
  $r=mysql_fetch_array($edit);

  
  echo "
   <div id='main-content'>
   <div class='container_12'>

   <div class='grid_12'>
   <div class='block-border'>
   <div class='block-header'>
   
   <h1>EDIT LINK TERKAIT</h1>
   </div>
   <div class='block-content'>	
	
   <form method=POST action=$aksi?module=linkterkait&act=update>
   <input type=hidden name=id value='$r[id_link]'>
		  
   <p class=inline-small-label> 
   <label for=field4>Nama Kampus</label>
   <input type=text name='judul' value='$r[judul]' size=40>
   </p> 

   <p class=inline-small-label> 
   <label for=field4>Singkatan</label>
   <input type=text name='singkatan' value='$r[singkatan]' style='width:350px' size=40>
   </p> 

   <p class=inline-small-label> 
   <label for=field4>URL Website</label>
   <input type=text name='url' value='$r[url]' size=40>
   </p> 

	 <br/><br/><div class=block-actions> 
      <ul class=actions-right> 
      <li>
      <a class='button red' id=reset-validate-form href='?module=linkterkait'>Batal</a>
      </li> </ul>
      <ul class=actions-left> 
      <li>
      <input type='submit' name='upload' class='button' value=' &nbsp;&nbsp;&nbsp;&nbsp; Simpan &nbsp;&nbsp;&nbsp;&nbsp;'>
	  </li> </ul>
	  </form>";
	  
	  
    break;  
   }
   //kurawal akhir hak akses module
   } else {
	echo akses_salah();
   }
   ?>




   </div> 
   </div>
   </div>
   <div class='clear height-fix'></div> 
   </div></div>