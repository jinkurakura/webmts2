<?php
session_start();
if (empty($_SESSION['username']) AND empty($_SESSION['passuser'])){

  echo "<link href='../../css/zalstyle.css' rel='stylesheet' type='text/css'>
  <link rel='shortcut icon' href='../../favicon.png' />
  
  <body class='special-page'>
  <div id='container'>
  <section id='error-number'>
  <img src='../../img/lock.png'>
  <h1>MODUL TIDAK DAPAT DIAKSES</h1>
  <p><span class style=\"font-size:14px; color:#ccc;\">Untuk mengakses modul, Anda harus login dahulu!</p></span><br/>
  </section>
  <section id='error-text'>
  <p><a class='button' href='../../index.php'> <b>LOGIN DI SINI</b> </a></p>
  </section>
  </div>";}
  
else{
include "../../../config/koneksi.php";
include "../../../config/fungsi_seo.php";

$module=$_GET[module];
$act=$_GET[act];
$tglsekarang = date("Y-m-d H:i:s");
// Hapus Kategori
if ($module=='linkterkait' AND $act=='hapus'){
  mysql_query("DELETE FROM link_terkait WHERE id_link='$_GET[id]'");
  header('location:../../media.php?module='.$module);
}

// Input kategori
elseif ($module=='linkterkait' AND $act=='input'){
  mysql_query("INSERT INTO link_terkait (judul,
                           singkatan,
                           url,
                           tanggal) 
                    VALUES('$_POST[judul]',
                           '$_POST[singkatan]',
                           '$_POST[url]',
                           '$tglsekarang')");
  header('location:../../media.php?module='.$module);
}

// Update kategori
elseif ($module=='linkterkait' AND $act=='update'){
  mysql_query("UPDATE link_terkait SET judul      ='$_POST[judul]', 
                                   singkatan  ='$_POST[singkatan]', 
                                   url        ='$_POST[url]' WHERE id_link = '$_POST[id]'");
  header('location:../../media.php?module='.$module);
}
}
?>
