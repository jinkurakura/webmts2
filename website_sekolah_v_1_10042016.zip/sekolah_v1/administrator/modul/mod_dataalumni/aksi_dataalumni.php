<?php
session_start();
if (empty($_SESSION['username']) AND empty($_SESSION['passuser'])){

  echo "<link href='../../css/zalstyle.css' rel='stylesheet' type='text/css'>
  <link rel='shortcut icon' href='../../favicon.png' />
  
  <body class='special-page'>
  <div id='container'>
  <section id='error-number'>
  <img src='../../img/lock.png'>
  <h1>MODUL TIDAK DAPAT DIAKSES</h1>
  <p><span class style=\"font-size:14px; color:#ccc;\">Untuk mengakses modul, Anda harus login dahulu!</p></span><br/>
  </section>
  <section id='error-text'>
  <p><a class='button' href='../../index.php'> <b>LOGIN DI SINI</b> </a></p>
  </section>
  </div>";}
  
else{
include "../../../config/koneksi.php";
include "../../../config/fungsi_seo.php";

$module=$_GET[module];
$act=$_GET[act];
$tglsekarang = date("Y-m-d H:i:s");
// Hapus Kategori
if ($module=='dataalumni' AND $act=='hapus'){
  mysql_query("DELETE FROM grafik_lulusan WHERE id_grafik='$_GET[id]'");
  header('location:../../media.php?module='.$module);
}

// Input kategori
elseif ($module=='dataalumni' AND $act=='input'){
  mysql_query("INSERT INTO grafik_lulusan (id_link,
                           jumlah,
                           tahun,
                           username) 
                    VALUES('$_POST[id_link]',
                           '$_POST[jumlah]',
                           '$_POST[tahun]',
                           '$_SESSION[namauser]')");
  header('location:../../media.php?module='.$module);
}

// Update kategori
elseif ($module=='dataalumni' AND $act=='update'){
  mysql_query("UPDATE grafik_lulusan SET id_link      ='$_POST[id_link]', 
                                          jumlah      ='$_POST[jumlah]', 
                                          tahun       ='$_POST[tahun]' WHERE id_grafik = '$_POST[id]'");
  header('location:../../media.php?module='.$module);
}
}
?>
