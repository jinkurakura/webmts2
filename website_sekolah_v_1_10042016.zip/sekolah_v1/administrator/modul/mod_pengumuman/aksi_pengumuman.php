<?php
session_start();
 if (empty($_SESSION['username']) AND empty($_SESSION['passuser'])){
  echo "<link href='style.css' rel='stylesheet' type='text/css'>
 <center>Untuk mengakses modul, Anda harus login <br>";
  echo "<a href=../../index.php><b>LOGIN</b></a></center>";
}
else{
include "../../../config/koneksi.php";
include "../../../config/library.php";
include "../../../config/fungsi_thumb.php";

$module=$_GET[module];
$act=$_GET[act];

// Hapus pengumuman
if ($module=='pengumuman' AND $act=='hapus'){
  mysql_query("DELETE FROM pengumuman WHERE id_pengumuman='$_GET[id]'");
  header('location:../../media.php?module='.$module);
}

// Input pengumuman
elseif ($module=='pengumuman' AND $act=='input'){
  $lokasi_file = $_FILES['fupload']['tmp_name'];
  $nama_file   = $_FILES['fupload']['name'];
  $tgljam = date("Y-m-d H:i:s");
  // Apabila ada gambar yang diupload
  if (!empty($lokasi_file)){
    UploadFile($nama_file);
    mysql_query("INSERT INTO pengumuman(judul,
                                    keterangan,
                                    nama_file,
                                    tanggal) 
                            VALUES('$_POST[judul]',
                                   '$_POST[keterangan]',
                                   '$nama_file',
                                   '$tgljam')");
  }
  else{
    mysql_query("INSERT INTO pengumuman(judul,
                                    keterangan,
                                    tanggal) 
                            VALUES('$_POST[judul]',
                                   '$_POST[keterangan]',
                                   '$tgljam')");
  }
  header('location:../../media.php?module='.$module);
}

// Update donwload
elseif ($module=='pengumuman' AND $act=='update'){
  $lokasi_file = $_FILES['fupload']['tmp_name'];
  $nama_file   = $_FILES['fupload']['name'];

  // Apabila gambar tidak diganti
  if (empty($lokasi_file)){
    mysql_query("UPDATE pengumuman SET judul      = '$_POST[judul]',
                                       keterangan = '$_POST[keterangan]' WHERE id_pengumuman = '$_POST[id]'");
  }else{
    UploadFile($nama_file);
    mysql_query("UPDATE pengumuman SET judul      = '$_POST[judul]',
                                       keterangan = '$_POST[keterangan]',
                                       nama_file  = '$nama_file' WHERE id_pengumuman = '$_POST[id]'");
  }
  header('location:../../media.php?module='.$module);
}
}
?>