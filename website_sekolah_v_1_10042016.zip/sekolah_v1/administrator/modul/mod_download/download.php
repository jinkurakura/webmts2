<script>
function confirmdelete(delUrl) {
   if (confirm("Anda yakin ingin menghapus?")) {
      document.location = delUrl;
   }
}
</script>


<?php
//cek hak akses user
$cek=user_akses($_GET[module],$_SESSION[sessid]);
if($cek==1 OR $_SESSION[leveluser]=='admin'){

$aksi="modul/mod_download/aksi_download.php";
switch($_GET[act]){
  // Tampil Download
  
  default:
echo "<div id=main-content> 
      <div class=container_12> 
      <div class=grid_12> 
      <br/>
	  <a href='?module=download&act=tambahdownload' class='button'>
     <span>Tambahkan File Download</span>
     </a></div>";

    if (empty($_GET['kata'])){
echo "<div class=grid_12> 
      <div class=block-border> 
      <div class=block-header> 
      <h1>FILE DOWNLOAD</h1>
      <span></span> 
      </div> 
       <div class='block-content'>
		  
     <table id='table-example' class='table'>	  
  	  
    <thead><tr>
    <th>No</th>
	<th>Judul</th>
	<th>Nama File</th>
	<th>Kategori</th>
	<th>Aksi</th>
  
    </thead>
    <tbody>";

    $p      = new Paging;
    $batas  = 15;
    $posisi = $p->cariPosisi($batas);

    if ($_SESSION[leveluser]=='admin'){
      $tampil = mysql_query("SELECT * FROM download a JOIN kategori_download b ON a.id_kategori_download=b.id_kategori_download ORDER BY a.id_download DESC");
    }
    else{
      $tampil=mysql_query("SELECT * FROM download
                           WHERE username='$_SESSION[namauser]'       
                           ORDER BY id_download DESC");
    }
  
    $no = $posisi+1;
    while($r=mysql_fetch_array($tampil)){
	$tgl=tgl_indo($r[tgl_posting]);
    $lebar=strlen($no);
    switch($lebar){
      case 1:
      {
        $g="0".$no;
        break;     
      }
      case 2:
      {
        $g=$no;
        break;     
      }      
    } 

       echo "<tr class=gradeX> 
  <td width=50><center>$g</center></td>
  <td>$r[judul]</td>
  <td>$r[nama_file]</td>
  <td>$r[nama_kategori_download]</td>
  <td width=80>
   
  <a href='?module=download&act=editdownload&id=$r[id_download]' title='Edit' class='with-tip'>
  <center><img src='img/edit.png'></a>
   
  <a href=javascript:confirmdelete('$aksi?module=download&act=hapus&id=$r[id_download]') title='Hapus' class='with-tip'>
  &nbsp;&nbsp;&nbsp;&nbsp;<img src='img/hapus.png'></center></a> 
   
  </td></tr>";
  
      $no++;
      }
echo "</tbody></table> ";

      if ($_SESSION[leveluser]=='admin'){
      $jmldata = mysql_num_rows(mysql_query("SELECT * FROM download"));
      }
        else{
      $jmldata = mysql_num_rows(mysql_query("SELECT * FROM download WHERE username='$_SESSION[namauser]'"));
      }  
      break;    
      }
      else{
echo " <table id='table-example' class='table'>	  
	  
     <thead><tr>
     <th>No</th>
	<th>Judul</th>
	<th>Nama File</th>
	<th>Tgl. Posting</th>
	<th>Aksi</th>
  
     </thead>
     <tbody>";

      if ($_SESSION[leveluser]=='admin'){
      $tampil = mysql_query("SELECT * FROM download WHERE judul LIKE '%$_GET[kata]%' ORDER BY id_download DESC");
      }
      else{
      $tampil=mysql_query("SELECT * FROM download 
                           WHERE username='$_SESSION[namauser]'
                           AND judul LIKE '%$_GET[kata]%'       
                           ORDER BY id_download DESC");
      }
  
      $no = $posisi+1;
      while($r=mysql_fetch_array($tampil)){
	  $tgl=tgl_indo($r[tgl_posting]);
echo "<tr class=gradeX> 
  <td><center>$no</center></td>
  
  <td>$r[judul]</td>
  <td>$r[nama_file]</td>
  <td>$tgl</td>
  <td width=80>
   
  <a href='?module=download&act=editdownload&id=$r[id_download]' title='Edit' class='with-tip'>
  <center><img src='img/edit.png'></a>
   
  <a href=javascript:confirmdelete('$aksi?module=download&act=hapus&id=$r[id_download]') title='Hapus' class='with-tip'>
  &nbsp;&nbsp;&nbsp;&nbsp;<img src='img/hapus.png'></center></a> 
   
  </td></tr>";
			 
  
      $no++;
     }
echo "</tbody></table> ";

      if ($_SESSION[leveluser]=='admin'){
      $jmldata = mysql_num_rows(mysql_query("SELECT * FROM download WHERE judul LIKE '%$_GET[kata]%'"));
      }
      else{
      $jmldata = mysql_num_rows(mysql_query("SELECT * FROM download WHERE username='$_SESSION[namauser]' AND judul LIKE '%$_GET[kata]%'"));
      }  
      break;    
      }
	  
//batas update/////////////////////////////////////////////////////////////////////////
  
  // Form Tambah Kategori
  case "tambahdownload":
  
  echo "
   <div id='main-content'>
   <div class='container_12'>

   <div class='grid_12'>
   <div class='block-border'>
   <div class='block-header'>
   
   <h1>TAMBAH FILE DOWNLOAD</h1>
   </div>
   <div class='block-content'>	
   
   <form method=POST action='$aksi?module=download&act=input' enctype='multipart/form-data'>
		  
   <p class=inline-small-label> 
   <label for=field4>Judul</label>
   <input type=text name='judul' size=40>
   </p> 
   
   <p class=inline-small-label> 
   <label for=field4>Kategori</label>
   <select name='kategori'>
   <option value=0 selected>Pilih Kategori File</option>";
   $tampil=mysql_query("SELECT * FROM kategori_download ORDER BY nama_kategori_download");
   while($r=mysql_fetch_array($tampil)){
   echo "<option value=$r[id_kategori_download]>$r[nama_kategori_download]</option>"; }
   
   echo "</select></p>

   <p class=inline-small-label> 
   <label for=field4>Cari File</label>
   <input type=file name='fupload' size=40>
   </p> 
   
  	  
      <div class=block-actions> 
      <ul class=actions-right> 
      <li>
      <a class='button red' id=reset-validate-form href='?module=download'>Batal</a>
      </li> </ul>
      <ul class=actions-left> 
      <li>
      <input type='submit' name='upload' class='button' value=' &nbsp;&nbsp;&nbsp;&nbsp; Simpan &nbsp;&nbsp;&nbsp;&nbsp;'>
	  </li> </ul>
	  </form>";
	  
     break;
  
  // Form Edit Download
  case "editdownload":
  $edit = mysql_query("SELECT * FROM download WHERE id_download='$_GET[id]'");
    $r    = mysql_fetch_array($edit);

  
  echo "
   <div id='main-content'>
   <div class='container_12'>

   <div class='grid_12'>
   <div class='block-border'>
   <div class='block-header'>
   
   <h1>EDIT FILE DOWNLOAD</h1>
   </div>
   <div class='block-content'>	
	
   <form method=POST enctype='multipart/form-data' action=$aksi?module=download&act=update>
          <input type=hidden name=id value=$r[id_download]>
		  
   <p class=inline-small-label> 
   <label for=field4>Judul</label>
   <input type=text name='judul' size=40 value='$r[judul]'>
   </p>

   <p class=inline-small-label> 
   <label for=field4>Kategori</label>
   <select name='kategori'>
   <option value=0 selected>Pilih Kategori File</option>";
   $tampil=mysql_query("SELECT * FROM kategori_download ORDER BY nama_kategori_download");
   while($t=mysql_fetch_array($tampil)){
	   if ($t[id_kategori_download]==$r[id_kategori_download]){
	   		echo "<option value=$t[id_kategori_download] selected>$t[nama_kategori_download]</option>"; 
	   }else{
	   		echo "<option value=$t[id_kategori_download]>$t[nama_kategori_download]</option>"; 
	   }
   }
   echo "</select></p>

   <p class=inline-small-label> 
   <label for=field4>File</label>
   $r[nama_file]<br/>
   </p>
   
   <p class=inline-small-label> 
   <label for=field4>Ganti File</label>
   <input type=file name='fupload' size=30>
   </p>";

	  echo " <br/><br/><div class=block-actions> 
      <ul class=actions-right> 
      <li>
      <a class='button red' id=reset-validate-form href='?module=download'>Batal</a>
      </li> </ul>
      <ul class=actions-left> 
      <li>
      <input type='submit' name='upload' class='button' value=' &nbsp;&nbsp;&nbsp;&nbsp; Simpan &nbsp;&nbsp;&nbsp;&nbsp;'>
	  </li> </ul>
	  </form>";
	  
	  
    break;  
   }
   //kurawal akhir hak akses module
   } else {
	echo akses_salah();
   }
   ?>
   </div> 
   </div>
   </div>
   <div class='clear height-fix'></div> 
   </div></div>