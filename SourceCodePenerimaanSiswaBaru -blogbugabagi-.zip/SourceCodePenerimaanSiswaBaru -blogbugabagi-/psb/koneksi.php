<?php
$h = "localhost";
$u = "root";
$p = "";
$d = "db_pendaftaran";
mysql_connect($h,$u,$p);
mysql_select_db($d);
?>