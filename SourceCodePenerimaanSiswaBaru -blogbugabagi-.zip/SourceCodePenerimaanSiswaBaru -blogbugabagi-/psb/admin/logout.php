<?php
  session_start();
  session_destroy();
  echo "Yakin Ingin Keluar ? <a href='../index.php'><b>Keluar<b></a>";
  header("../index.php");
  // echo "<meta http-equiv='refresh' content='0; url=../index.php'>";
?>
