<h2>Selamat Datang di Sistem Online Pendaftaran Siswa Baru</h2>
	<p>Tes Soal Online merupakan bagian dari sistem pembelajaran digital atau e-learning. Dimana kita diharapkan untuk bisa belajar secara mandiri tanpa terbatas oleh waktu dan tempat. Semoga melalui E-Learning dan Sistem Tes Soal Online ini, dapat tercapainya proses pembelajaran yang efektif dan efisien. Salam Hangat.</p>
	<div class="cleaner_h20"></div>
	<ul>
	<li>Isi user ID dan password dengan benar. Jika belum tahu atau tidak berhasil, tanyakan pada pengawas, jika anda telah mengisi dengan benar maka nama ada akan muncul di layar sebelah kiri (side bar).</li>
	<li>Pilih soal sesuai petunjuk guru atau pengawas, isi password soal dengan benar.</li>
	<li>Selama mengerjakan soal tidak perlu menggunakan keyboard. Penekanan ENTER akan dianggap anda telah menyelesaikan soal.</li>
	<li>Kerjakan soal secara hati-hati, klik pada lingkaran di sebelah kiri pilihan yang kamu anggap benar.</li>
	<li>Perhatikan waktu tersisa di atas jika mencapai 0 menit, soal akan ditutup dan dikoreksi secara otomatis.</li>
	<li>Jika anda sudah menyelesaikan soal sebelum waktu habis, klik tombol selesai pada lembar soal bagian paling bawah.</li>
	</ul>