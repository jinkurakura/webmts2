<h2>Tentang Saya - Gede Lumbung</h2>
<div class="cleaner_h5"></div>

<img src="images/lumbung-amobius.jpg" vspace="5" hspace="5" style="padding:3px; margin:5px; border:1px solid #999999; float:left; width:80px;" />Saya ini cuma mahasiswa TI biasa, yang masih sangat kutu kupret + sontoloyo dan jauh dari kata sempurna. Selain itu juga, seorang mahasiswa yang tidak puas dengan keadilan yang diterapkan di kampus. Bisa dibilang, saya ini adalah salah satu makhluk open source. Gara-gara semangat open source yang sangat tinggi, akhirnya saya banyak menerima proyek 2M (Makasi Mas) alias proyek TengKyu. Yang penting tetap semangat aja deh, hitung-hitung cari pengalaman (alasan lawas)..
	