
<h2>Grafik Pendaftaran Online Siswa Baru SMAN 1 Wongsorejo</h2>
	<div class="cleaner_h10"></div>
<div id="hasil"></div>
<?php
include_once 'ofc-library/open_flash_chart_object.php';
open_flash_chart_object( 600, 300, 'http://'. $_SERVER['SERVER_NAME'] .'/109x/chart.php' );
?>